const express = require('express')
const app = express()
const { engine } = require('express-handlebars')
const bodyParser = require('body-parser')

// Configurações
// Template Engine
app.engine('handlebars', engine({
    defaultLayout: 'main',   // Layout principal
    layoutsDir: __dirname + '/views/layouts/' 
}))
app.set('view engine', 'handlebars')
app.set('views', __dirname + '/views/layouts')
// Body Parser
app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json())
// Conexão com o BD MySQL
const Sequelize = require('sequelize')
//                               banco   user    senha
const sequelize = new Sequelize('test', 'root', '123456', {
    host: 'localhost',
    dialect: 'mysql'
})

// Rotas
app.get('/cad', function(req, res) {
    res.render('formulario')  // Renderiza o template formulario.handlebars
})

app.post('/add', function(req, res){
    res.send("FORMULARIO RECEBIDO!")
})
app.listen(8081, function() {
    console.log("Servidor rodando!")
})

//aula22